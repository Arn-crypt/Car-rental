using Microsoft.Data.SqlClient;

namespace CarRentalApp
{
    public static class Db
    {
        
        private const string ConnStr =
            @"Server=(localdb)\MSSQLLocalDB;Database=CarRentalDb;Trusted_Connection=True;TrustServerCertificate=True;";

        public static List<Car> GetCars()
        {
            var list = new List<Car>();
            using var conn = new SqlConnection(ConnStr);
            using var cmd = new SqlCommand(
                "SELECT Id, Name, Type, DailyRate, IsAvailable FROM Cars ORDER BY Id", conn);
            conn.Open();
            using var r = cmd.ExecuteReader();
            while (r.Read())
            {
                list.Add(new Car
                {
                    Id = r.GetInt32(0),
                    Name = r.GetString(1),
                    Type = r.GetString(2),
                    PricePerDay = r.GetDecimal(3),
                    Available = r.GetBoolean(4)
                });
            }
            return list;
        }

        public static List<Rental> GetActiveRentals()
        {
            var list = new List<Rental>();
            using var conn = new SqlConnection(ConnStr);
            using var cmd = new SqlCommand(
                @"SELECT r.Id, r.CustomerName, r.Phone, c.Name, r.PickupDate, r.ReturnDate, r.Total
                  FROM Rentals r JOIN Cars c ON c.Id = r.CarId
                  WHERE r.IsReturned = 0
                  ORDER BY r.Id DESC", conn);
            conn.Open();
            using var r = cmd.ExecuteReader();
            while (r.Read())
            {
                var pickup = r.GetDateTime(4);
                var ret = r.GetDateTime(5);
                list.Add(new Rental
                {
                    Id = r.GetInt32(0),
                    Customer = r.GetString(1),
                    Phone = r.IsDBNull(2) ? "" : r.GetString(2),
                    Car = r.GetString(3),
                    Pickup = pickup,
                    Return = ret,
                    Days = (ret.Date - pickup.Date).Days,
                    Total = r.GetDecimal(6)
                });
            }
            return list;
        }

        public static void AddRental(int carId, string customer, string phone,
                                     DateTime pickup, DateTime ret, decimal total)
        {
            using var conn = new SqlConnection(ConnStr);
            conn.Open();
            using var tx = conn.BeginTransaction();

            
            using (var reserve = new SqlCommand(
                "UPDATE Cars SET IsAvailable = 0 WHERE Id = @id AND IsAvailable = 1", conn, tx))
            {
                reserve.Parameters.AddWithValue("@id", carId);
                if (reserve.ExecuteNonQuery() == 0)
                    throw new InvalidOperationException("That car is no longer available.");
            }

            using (var insert = new SqlCommand(
                @"INSERT INTO Rentals (CarId, CustomerName, Phone, PickupDate, ReturnDate, Total)
                  VALUES (@car, @name, @phone, @pickup, @ret, @total)", conn, tx))
            {
                insert.Parameters.AddWithValue("@car", carId);
                insert.Parameters.AddWithValue("@name", customer);
                insert.Parameters.AddWithValue("@phone", phone);
                insert.Parameters.AddWithValue("@pickup", pickup.Date);
                insert.Parameters.AddWithValue("@ret", ret.Date);
                insert.Parameters.AddWithValue("@total", total);
                insert.ExecuteNonQuery();
            }
            tx.Commit();
        }

        public static void MarkReturned(int rentalId)
        {
            using var conn = new SqlConnection(ConnStr);
            conn.Open();
            using var tx = conn.BeginTransaction();
            using var cmd = new SqlCommand(
                @"UPDATE Rentals SET IsReturned = 1 WHERE Id = @id AND IsReturned = 0;
                  IF @@ROWCOUNT > 0
                      UPDATE Cars SET IsAvailable = 1
                      WHERE Id = (SELECT CarId FROM Rentals WHERE Id = @id);", conn, tx);
            cmd.Parameters.AddWithValue("@id", rentalId);
            cmd.ExecuteNonQuery();
            tx.Commit();
        }
    }
}