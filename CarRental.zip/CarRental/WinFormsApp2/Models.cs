namespace CarRentalApp
{
    public class Car
    {
        public int Id { get; set; }
        public string Name { get; set; } = "";
        public string Type { get; set; } = "";
        public decimal PricePerDay { get; set; }
        public bool Available { get; set; } = true;
        public override string ToString() => $"{Name} ({Type}) - ${PricePerDay}/day";
    }

    public class Rental
    {
        public int Id { get; set; }
        public string Customer { get; set; } = "";
        public string Phone { get; set; } = "";
        public string Car { get; set; } = "";
        public DateTime Pickup { get; set; }
        public DateTime Return { get; set; }
        public int Days { get; set; }
        public decimal Total { get; set; }
    }
}