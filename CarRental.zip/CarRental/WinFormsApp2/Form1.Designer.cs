﻿namespace CarRentalApp
{
    partial class Form1
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            pnlSidebar = new Panel();
            btnRentals = new Button();
            btnBook = new Button();
            btnBrowse = new Button();
            lblLogo = new Label();
            pnlHeader = new Panel();
            lblTitle = new Label();
            tabMain = new TabControl();
            tabBrowse = new TabPage();
            dgvCars = new DataGridView();
            pnlBrowseBottom = new Panel();
            btnRentSelected = new Button();
            pnlFilter = new Panel();
            cmbFilter = new ComboBox();
            txtSearch = new TextBox();
            tabBook = new TabPage();
            pnlBookForm = new Panel();
            btnConfirm = new Button();
            lblTotal = new Label();
            lblDays = new Label();
            dtReturn = new DateTimePicker();
            lblReturnCaption = new Label();
            dtPickup = new DateTimePicker();
            lblPickupCaption = new Label();
            cmbCar = new ComboBox();
            lblCarCaption = new Label();
            txtPhone = new TextBox();
            lblPhoneCaption = new Label();
            txtName = new TextBox();
            lblNameCaption = new Label();
            tabRentals = new TabPage();
            dgvRentals = new DataGridView();
            pnlRentalsBottom = new Panel();
            btnReturn = new Button();
            pnlSidebar.SuspendLayout();
            pnlHeader.SuspendLayout();
            tabMain.SuspendLayout();
            tabBrowse.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dgvCars).BeginInit();
            pnlBrowseBottom.SuspendLayout();
            pnlFilter.SuspendLayout();
            tabBook.SuspendLayout();
            pnlBookForm.SuspendLayout();
            tabRentals.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dgvRentals).BeginInit();
            pnlRentalsBottom.SuspendLayout();
            SuspendLayout();

            pnlSidebar.BackColor = Color.FromArgb(28, 34, 48);
            pnlSidebar.Controls.Add(btnRentals);
            pnlSidebar.Controls.Add(btnBook);
            pnlSidebar.Controls.Add(btnBrowse);
            pnlSidebar.Controls.Add(lblLogo);
            pnlSidebar.Dock = DockStyle.Left;
            pnlSidebar.Location = new Point(0, 0);
            pnlSidebar.Name = "pnlSidebar";
            pnlSidebar.Size = new Size(210, 661);
            pnlSidebar.TabIndex = 2;

            btnRentals.BackColor = Color.FromArgb(28, 34, 48);
            btnRentals.Cursor = Cursors.Hand;
            btnRentals.Dock = DockStyle.Top;
            btnRentals.FlatAppearance.BorderSize = 0;
            btnRentals.FlatAppearance.MouseOverBackColor = Color.FromArgb(45, 55, 78);
            btnRentals.FlatStyle = FlatStyle.Flat;
            btnRentals.ForeColor = Color.White;
            btnRentals.Location = new Point(0, 174);
            btnRentals.Name = "btnRentals";
            btnRentals.Padding = new Padding(20, 0, 0, 0);
            btnRentals.Size = new Size(210, 52);
            btnRentals.TabIndex = 3;
            btnRentals.Text = "📋   Rentals";
            btnRentals.TextAlign = ContentAlignment.MiddleLeft;
            btnRentals.UseVisualStyleBackColor = false;

            btnBook.BackColor = Color.FromArgb(28, 34, 48);
            btnBook.Cursor = Cursors.Hand;
            btnBook.Dock = DockStyle.Top;
            btnBook.FlatAppearance.BorderSize = 0;
            btnBook.FlatAppearance.MouseOverBackColor = Color.FromArgb(45, 55, 78);
            btnBook.FlatStyle = FlatStyle.Flat;
            btnBook.ForeColor = Color.White;
            btnBook.Location = new Point(0, 122);
            btnBook.Name = "btnBook";
            btnBook.Padding = new Padding(20, 0, 0, 0);
            btnBook.Size = new Size(210, 52);
            btnBook.TabIndex = 2;
            btnBook.Text = "📝   Book a Car";
            btnBook.TextAlign = ContentAlignment.MiddleLeft;
            btnBook.UseVisualStyleBackColor = false;

            btnBrowse.BackColor = Color.FromArgb(0, 120, 215);
            btnBrowse.Cursor = Cursors.Hand;
            btnBrowse.Dock = DockStyle.Top;
            btnBrowse.FlatAppearance.BorderSize = 0;
            btnBrowse.FlatAppearance.MouseOverBackColor = Color.FromArgb(45, 55, 78);
            btnBrowse.FlatStyle = FlatStyle.Flat;
            btnBrowse.ForeColor = Color.White;
            btnBrowse.Location = new Point(0, 70);
            btnBrowse.Name = "btnBrowse";
            btnBrowse.Padding = new Padding(20, 0, 0, 0);
            btnBrowse.Size = new Size(210, 52);
            btnBrowse.TabIndex = 1;
            btnBrowse.Text = "🔍   Browse Cars";
            btnBrowse.TextAlign = ContentAlignment.MiddleLeft;
            btnBrowse.UseVisualStyleBackColor = false;

            lblLogo.Dock = DockStyle.Top;
            lblLogo.Font = new Font("Segoe UI Semibold", 16F);
            lblLogo.ForeColor = Color.White;
            lblLogo.Location = new Point(0, 0);
            lblLogo.Name = "lblLogo";
            lblLogo.Size = new Size(210, 70);
            lblLogo.TabIndex = 0;
            lblLogo.Text = "🚗  DriveEasy";
            lblLogo.TextAlign = ContentAlignment.MiddleCenter;

            pnlHeader.BackColor = Color.White;
            pnlHeader.Controls.Add(lblTitle);
            pnlHeader.Dock = DockStyle.Top;
            pnlHeader.Location = new Point(210, 0);
            pnlHeader.Name = "pnlHeader";
            pnlHeader.Size = new Size(874, 70);
            pnlHeader.TabIndex = 1;

            lblTitle.Dock = DockStyle.Fill;
            lblTitle.Font = new Font("Segoe UI Semibold", 18F);
            lblTitle.ForeColor = Color.FromArgb(28, 34, 48);
            lblTitle.Location = new Point(0, 0);
            lblTitle.Name = "lblTitle";
            lblTitle.Padding = new Padding(20, 0, 0, 0);
            lblTitle.Size = new Size(874, 70);
            lblTitle.TabIndex = 0;
            lblTitle.Text = "Browse Cars";
            lblTitle.TextAlign = ContentAlignment.MiddleLeft;

            tabMain.Controls.Add(tabBrowse);
            tabMain.Controls.Add(tabBook);
            tabMain.Controls.Add(tabRentals);
            tabMain.Dock = DockStyle.Fill;
            tabMain.Location = new Point(210, 70);
            tabMain.Name = "tabMain";
            tabMain.SelectedIndex = 0;
            tabMain.Size = new Size(874, 591);
            tabMain.TabIndex = 0;

            tabBrowse.BackColor = Color.FromArgb(244, 246, 250);
            tabBrowse.Controls.Add(dgvCars);
            tabBrowse.Controls.Add(pnlBrowseBottom);
            tabBrowse.Controls.Add(pnlFilter);
            tabBrowse.Location = new Point(4, 26);
            tabBrowse.Name = "tabBrowse";
            tabBrowse.Padding = new Padding(20);
            tabBrowse.Size = new Size(866, 561);
            tabBrowse.TabIndex = 0;
            tabBrowse.Text = "Browse Cars";

            dgvCars.Dock = DockStyle.Fill;
            dgvCars.Location = new Point(20, 70);
            dgvCars.Name = "dgvCars";
            dgvCars.RowHeadersWidth = 62;
            dgvCars.Size = new Size(826, 415);
            dgvCars.TabIndex = 1;

            pnlBrowseBottom.Controls.Add(btnRentSelected);
            pnlBrowseBottom.Dock = DockStyle.Bottom;
            pnlBrowseBottom.Location = new Point(20, 485);
            pnlBrowseBottom.Name = "pnlBrowseBottom";
            pnlBrowseBottom.Size = new Size(826, 56);
            pnlBrowseBottom.TabIndex = 2;

            btnRentSelected.BackColor = Color.FromArgb(0, 120, 215);
            btnRentSelected.Cursor = Cursors.Hand;
            btnRentSelected.FlatAppearance.BorderSize = 0;
            btnRentSelected.FlatStyle = FlatStyle.Flat;
            btnRentSelected.ForeColor = Color.White;
            btnRentSelected.Location = new Point(0, 10);
            btnRentSelected.Name = "btnRentSelected";
            btnRentSelected.Size = new Size(200, 38);
            btnRentSelected.TabIndex = 0;
            btnRentSelected.Text = "Rent selected car";
            btnRentSelected.UseVisualStyleBackColor = false;

            pnlFilter.Controls.Add(cmbFilter);
            pnlFilter.Controls.Add(txtSearch);
            pnlFilter.Dock = DockStyle.Top;
            pnlFilter.Location = new Point(20, 20);
            pnlFilter.Name = "pnlFilter";
            pnlFilter.Size = new Size(826, 50);
            pnlFilter.TabIndex = 0;

            cmbFilter.DropDownStyle = ComboBoxStyle.DropDownList;
            cmbFilter.FormattingEnabled = true;
            cmbFilter.Items.AddRange(new object[] { "All", "Sedan", "SUV", "Van", "Hatchback" });
            cmbFilter.Location = new Point(280, 8);
            cmbFilter.Name = "cmbFilter";
            cmbFilter.Size = new Size(160, 25);
            cmbFilter.TabIndex = 1;

            txtSearch.Location = new Point(0, 8);
            txtSearch.Name = "txtSearch";
            txtSearch.PlaceholderText = "Search car name...";
            txtSearch.Size = new Size(260, 25);
            txtSearch.TabIndex = 0;

            tabBook.BackColor = Color.FromArgb(244, 246, 250);
            tabBook.Controls.Add(pnlBookForm);
            tabBook.Location = new Point(4, 24);
            tabBook.Name = "tabBook";
            tabBook.Padding = new Padding(20);
            tabBook.Size = new Size(866, 563);
            tabBook.TabIndex = 1;
            tabBook.Text = "Book a Car";

            pnlBookForm.BackColor = Color.White;
            pnlBookForm.Controls.Add(btnConfirm);
            pnlBookForm.Controls.Add(lblTotal);
            pnlBookForm.Controls.Add(lblDays);
            pnlBookForm.Controls.Add(dtReturn);
            pnlBookForm.Controls.Add(lblReturnCaption);
            pnlBookForm.Controls.Add(dtPickup);
            pnlBookForm.Controls.Add(lblPickupCaption);
            pnlBookForm.Controls.Add(cmbCar);
            pnlBookForm.Controls.Add(lblCarCaption);
            pnlBookForm.Controls.Add(txtPhone);
            pnlBookForm.Controls.Add(lblPhoneCaption);
            pnlBookForm.Controls.Add(txtName);
            pnlBookForm.Controls.Add(lblNameCaption);
            pnlBookForm.Location = new Point(20, 20);
            pnlBookForm.Name = "pnlBookForm";
            pnlBookForm.Size = new Size(480, 500);
            pnlBookForm.TabIndex = 0;

            btnConfirm.BackColor = Color.FromArgb(0, 120, 215);
            btnConfirm.Cursor = Cursors.Hand;
            btnConfirm.FlatAppearance.BorderSize = 0;
            btnConfirm.FlatStyle = FlatStyle.Flat;
            btnConfirm.ForeColor = Color.White;
            btnConfirm.Location = new Point(24, 444);
            btnConfirm.Name = "btnConfirm";
            btnConfirm.Size = new Size(420, 42);
            btnConfirm.TabIndex = 12;
            btnConfirm.Text = "Confirm Booking";
            btnConfirm.UseVisualStyleBackColor = false;

            lblTotal.Font = new Font("Segoe UI Semibold", 15F);
            lblTotal.ForeColor = Color.FromArgb(0, 120, 215);
            lblTotal.Location = new Point(24, 400);
            lblTotal.Name = "lblTotal";
            lblTotal.Size = new Size(420, 34);
            lblTotal.TabIndex = 11;
            lblTotal.Text = "Total: $0.00";

            lblDays.Location = new Point(24, 374);
            lblDays.Name = "lblDays";
            lblDays.Size = new Size(420, 24);
            lblDays.TabIndex = 10;
            lblDays.Text = "1 day(s)";

            dtReturn.Format = DateTimePickerFormat.Short;
            dtReturn.Location = new Point(24, 324);
            dtReturn.Name = "dtReturn";
            dtReturn.Size = new Size(420, 25);
            dtReturn.TabIndex = 9;

            lblReturnCaption.ForeColor = Color.DimGray;
            lblReturnCaption.Location = new Point(24, 300);
            lblReturnCaption.Name = "lblReturnCaption";
            lblReturnCaption.Size = new Size(420, 22);
            lblReturnCaption.TabIndex = 8;
            lblReturnCaption.Text = "Return date";

            dtPickup.Format = DateTimePickerFormat.Short;
            dtPickup.Location = new Point(24, 254);
            dtPickup.Name = "dtPickup";
            dtPickup.Size = new Size(420, 25);
            dtPickup.TabIndex = 7;

            lblPickupCaption.ForeColor = Color.DimGray;
            lblPickupCaption.Location = new Point(24, 230);
            lblPickupCaption.Name = "lblPickupCaption";
            lblPickupCaption.Size = new Size(420, 22);
            lblPickupCaption.TabIndex = 6;
            lblPickupCaption.Text = "Pick-up date";

            cmbCar.DropDownStyle = ComboBoxStyle.DropDownList;
            cmbCar.FormattingEnabled = true;
            cmbCar.Location = new Point(24, 184);
            cmbCar.Name = "cmbCar";
            cmbCar.Size = new Size(420, 25);
            cmbCar.TabIndex = 5;

            lblCarCaption.ForeColor = Color.DimGray;
            lblCarCaption.Location = new Point(24, 160);
            lblCarCaption.Name = "lblCarCaption";
            lblCarCaption.Size = new Size(420, 22);
            lblCarCaption.TabIndex = 4;
            lblCarCaption.Text = "Car";

            txtPhone.Location = new Point(24, 114);
            txtPhone.Name = "txtPhone";
            txtPhone.Size = new Size(420, 25);
            txtPhone.TabIndex = 3;

            lblPhoneCaption.ForeColor = Color.DimGray;
            lblPhoneCaption.Location = new Point(24, 90);
            lblPhoneCaption.Name = "lblPhoneCaption";
            lblPhoneCaption.Size = new Size(420, 22);
            lblPhoneCaption.TabIndex = 2;
            lblPhoneCaption.Text = "Phone";

            txtName.Location = new Point(24, 44);
            txtName.Name = "txtName";
            txtName.Size = new Size(420, 25);
            txtName.TabIndex = 1;

            lblNameCaption.ForeColor = Color.DimGray;
            lblNameCaption.Location = new Point(24, 20);
            lblNameCaption.Name = "lblNameCaption";
            lblNameCaption.Size = new Size(420, 22);
            lblNameCaption.TabIndex = 0;
            lblNameCaption.Text = "Customer name";

            tabRentals.BackColor = Color.FromArgb(244, 246, 250);
            tabRentals.Controls.Add(dgvRentals);
            tabRentals.Controls.Add(pnlRentalsBottom);
            tabRentals.Location = new Point(4, 24);
            tabRentals.Name = "tabRentals";
            tabRentals.Padding = new Padding(20);
            tabRentals.Size = new Size(866, 563);
            tabRentals.TabIndex = 2;
            tabRentals.Text = "Rentals";

            dgvRentals.Dock = DockStyle.Fill;
            dgvRentals.Location = new Point(20, 20);
            dgvRentals.Name = "dgvRentals";
            dgvRentals.RowHeadersWidth = 62;
            dgvRentals.Size = new Size(826, 467);
            dgvRentals.TabIndex = 0;

            pnlRentalsBottom.Controls.Add(btnReturn);
            pnlRentalsBottom.Dock = DockStyle.Bottom;
            pnlRentalsBottom.Location = new Point(20, 487);
            pnlRentalsBottom.Name = "pnlRentalsBottom";
            pnlRentalsBottom.Size = new Size(826, 56);
            pnlRentalsBottom.TabIndex = 1;

            btnReturn.BackColor = Color.SeaGreen;
            btnReturn.Cursor = Cursors.Hand;
            btnReturn.FlatAppearance.BorderSize = 0;
            btnReturn.FlatStyle = FlatStyle.Flat;
            btnReturn.ForeColor = Color.White;
            btnReturn.Location = new Point(0, 10);
            btnReturn.Name = "btnReturn";
            btnReturn.Size = new Size(180, 38);
            btnReturn.TabIndex = 0;
            btnReturn.Text = "Mark as Returned";
            btnReturn.UseVisualStyleBackColor = false;

            AutoScaleDimensions = new SizeF(7F, 17F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(244, 246, 250);
            ClientSize = new Size(1084, 661);
            Controls.Add(tabMain);
            Controls.Add(pnlHeader);
            Controls.Add(pnlSidebar);
            Font = new Font("Segoe UI", 10F);
            MinimumSize = new Size(900, 600);
            Name = "Form1";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "DriveEasy - Car Rental";

            pnlSidebar.ResumeLayout(false);
            pnlHeader.ResumeLayout(false);
            tabMain.ResumeLayout(false);
            tabBrowse.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)dgvCars).EndInit();
            pnlBrowseBottom.ResumeLayout(false);
            pnlFilter.ResumeLayout(false);
            pnlFilter.PerformLayout();
            tabBook.ResumeLayout(false);
            pnlBookForm.ResumeLayout(false);
            pnlBookForm.PerformLayout();
            tabRentals.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)dgvRentals).EndInit();
            pnlRentalsBottom.ResumeLayout(false);
            ResumeLayout(false);
        }

        #endregion

        private System.Windows.Forms.Panel pnlSidebar;
        private System.Windows.Forms.Button btnRentals;
        private System.Windows.Forms.Button btnBook;
        private System.Windows.Forms.Button btnBrowse;
        private System.Windows.Forms.Label lblLogo;
        private System.Windows.Forms.Panel pnlHeader;
        private System.Windows.Forms.Label lblTitle;
        private System.Windows.Forms.TabControl tabMain;
        private System.Windows.Forms.TabPage tabBrowse;
        private System.Windows.Forms.DataGridView dgvCars;
        private System.Windows.Forms.Panel pnlBrowseBottom;
        private System.Windows.Forms.Button btnRentSelected;
        private System.Windows.Forms.Panel pnlFilter;
        private System.Windows.Forms.ComboBox cmbFilter;
        private System.Windows.Forms.TextBox txtSearch;
        private System.Windows.Forms.TabPage tabBook;
        private System.Windows.Forms.Panel pnlBookForm;
        private System.Windows.Forms.Button btnConfirm;
        private System.Windows.Forms.Label lblTotal;
        private System.Windows.Forms.Label lblDays;
        private System.Windows.Forms.DateTimePicker dtReturn;
        private System.Windows.Forms.Label lblReturnCaption;
        private System.Windows.Forms.DateTimePicker dtPickup;
        private System.Windows.Forms.Label lblPickupCaption;
        private System.Windows.Forms.ComboBox cmbCar;
        private System.Windows.Forms.Label lblCarCaption;
        private System.Windows.Forms.TextBox txtPhone;
        private System.Windows.Forms.Label lblPhoneCaption;
        private System.Windows.Forms.TextBox txtName;
        private System.Windows.Forms.Label lblNameCaption;
        private System.Windows.Forms.TabPage tabRentals;
        private System.Windows.Forms.DataGridView dgvRentals;
        private System.Windows.Forms.Panel pnlRentalsBottom;
        private System.Windows.Forms.Button btnReturn;
    }
}