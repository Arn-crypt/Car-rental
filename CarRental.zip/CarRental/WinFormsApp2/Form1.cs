﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using System.Xml.Linq;

namespace CarRentalApp
{
    public partial class Form1 : Form
    {
        static readonly Color Dark = Color.FromArgb(28, 34, 48);
        static readonly Color Accent = Color.FromArgb(0, 120, 215);

        List<Car> cars = new();
        List<Rental> rentals = new();

        public Form1()
        {
            InitializeComponent();

            tabMain.Appearance = TabAppearance.FlatButtons;
            tabMain.ItemSize = new Size(0, 1);
            tabMain.SizeMode = TabSizeMode.Fixed;

            StyleGrid(dgvCars);
            StyleGrid(dgvRentals);
            dgvRentals.DataBindingComplete += (s, e) =>
            {
                if (dgvRentals.Columns["Id"] != null) dgvRentals.Columns["Id"].Visible = false;
                if (dgvRentals.Columns["Total"] != null) dgvRentals.Columns["Total"].DefaultCellStyle.Format = "C2";
                if (dgvRentals.Columns["Pickup"] != null) dgvRentals.Columns["Pickup"].DefaultCellStyle.Format = "d";
                if (dgvRentals.Columns["Return"] != null) dgvRentals.Columns["Return"].DefaultCellStyle.Format = "d";
            };

            dtPickup.MinDate = DateTime.Today;
            dtReturn.MinDate = DateTime.Today;
            dtReturn.Value = DateTime.Today.AddDays(1);

            cmbFilter.SelectedIndex = 0;

            btnBrowse.Click += (s, e) => ShowTab(0, "Browse Cars", btnBrowse);
            btnBook.Click += (s, e) => ShowTab(1, "Book a Car", btnBook);
            btnRentals.Click += (s, e) => ShowTab(2, "Rentals", btnRentals);

            txtSearch.TextChanged += (s, e) => RefreshCars();
            cmbFilter.SelectedIndexChanged += (s, e) => RefreshCars();
            btnRentSelected.Click += BtnRentSelected_Click;

            cmbCar.SelectedIndexChanged += (s, e) => UpdateTotal();
            dtPickup.ValueChanged += (s, e) =>
            {
                if (dtReturn.Value <= dtPickup.Value) dtReturn.Value = dtPickup.Value.AddDays(1);
                UpdateTotal();
            };
            dtReturn.ValueChanged += (s, e) => UpdateTotal();
            btnConfirm.Click += ConfirmBooking;
            btnReturn.Click += BtnReturn_Click;

            ShowTab(0, "Browse Cars", btnBrowse);

            Load += (s, e) => SafeLoad();
        }

      
        void SafeLoad()
        {
            try { LoadData(); }
            catch (Exception ex)
            {
                MessageBox.Show("Could not load data from SQL Server:\n\n" + ex.Message,
                    "Database error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        void LoadData()
        {
            cars = Db.GetCars();
            rentals = Db.GetActiveRentals();
            dgvRentals.DataSource = rentals;
            RefreshCars();
            RefreshCarCombo();
        }

        void StyleGrid(DataGridView g)
        {
            g.ReadOnly = true;
            g.AllowUserToAddRows = false;
            g.AllowUserToDeleteRows = false;
            g.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            g.MultiSelect = false;
            g.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            g.BackgroundColor = Color.White;
            g.BorderStyle = BorderStyle.None;
            g.RowHeadersVisible = false;
            g.EnableHeadersVisualStyles = false;
            g.ColumnHeadersDefaultCellStyle.BackColor = Dark;
            g.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
            g.ColumnHeadersHeight = 36;
            g.DefaultCellStyle.SelectionBackColor = Accent;
            g.RowTemplate.Height = 32;
        }

        void ShowTab(int index, string title, Button activeNav)
        {
            tabMain.SelectedIndex = index;
            lblTitle.Text = title;
            foreach (var b in new[] { btnBrowse, btnBook, btnRentals }) b.BackColor = Dark;
            activeNav.BackColor = Accent;
        }

        
        void RefreshCars()
        {
            var q = cars.AsEnumerable();
            if (cmbFilter.SelectedItem != null && cmbFilter.SelectedItem.ToString() != "All")
                q = q.Where(c => c.Type == cmbFilter.SelectedItem.ToString());
            if (!string.IsNullOrWhiteSpace(txtSearch.Text))
                q = q.Where(c => c.Name.IndexOf(txtSearch.Text, StringComparison.OrdinalIgnoreCase) >= 0);

            dgvCars.DataSource = q.ToList();
            if (dgvCars.Columns["Id"] != null)
                dgvCars.Columns["Id"].Visible = false;
            if (dgvCars.Columns["PricePerDay"] != null)
                dgvCars.Columns["PricePerDay"].DefaultCellStyle.Format = "C2";
        }

        void BtnRentSelected_Click(object? sender, EventArgs e)
        {
            if (dgvCars.CurrentRow?.DataBoundItem is Car car)
            {
                if (!car.Available)
                {
                    MessageBox.Show("That car is already rented.", "Unavailable",
                        MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return;
                }
                cmbCar.SelectedItem = cmbCar.Items.Cast<Car>().FirstOrDefault(c => c.Id == car.Id);
                ShowTab(1, "Book a Car", btnBook);
            }
        }

        
        void RefreshCarCombo()
        {
            cmbCar.DataSource = cars.Where(c => c.Available).ToList();
            UpdateTotal();
        }

        void UpdateTotal()
        {
            if (cmbCar.SelectedItem == null)
            {
                lblDays.Text = "";
                lblTotal.Text = "Total: $0.00";
                return;
            }
            var car = (Car)cmbCar.SelectedItem;
            int days = Math.Max(1, (dtReturn.Value.Date - dtPickup.Value.Date).Days);
            lblDays.Text = $"{days} day(s) x ${car.PricePerDay}";
            lblTotal.Text = $"Total: ${days * car.PricePerDay:N2}";
        }

        void ConfirmBooking(object? sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtName.Text) || string.IsNullOrWhiteSpace(txtPhone.Text))
            {
                MessageBox.Show("Please enter the customer's name and phone.", "Missing info",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            if (cmbCar.SelectedItem == null)
            {
                MessageBox.Show("No car available to book.", "Unavailable",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            if (dtReturn.Value.Date <= dtPickup.Value.Date)
            {
                MessageBox.Show("Return date must be after pick-up date.", "Invalid dates",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            var car = (Car)cmbCar.SelectedItem;
            int days = (dtReturn.Value.Date - dtPickup.Value.Date).Days;
            decimal total = days * car.PricePerDay;

            try
            {
                Db.AddRental(car.Id, txtName.Text.Trim(), txtPhone.Text.Trim(),
                             dtPickup.Value, dtReturn.Value, total);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Booking failed",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                SafeLoad();   // refresh in case the car was taken
                return;
            }

            MessageBox.Show($"Booked {car.Name} for {days} day(s).\nTotal: ${total:N2}",
                "Booking confirmed", MessageBoxButtons.OK, MessageBoxIcon.Information);

            txtName.Clear();
            txtPhone.Clear();
            SafeLoad();
            ShowTab(2, "Rentals", btnRentals);
        }

       
        void BtnReturn_Click(object? sender, EventArgs e)
        {
            if (dgvRentals.CurrentRow?.DataBoundItem is Rental r)
            {
                try { Db.MarkReturned(r.Id); }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message, "Error",
                        MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
                SafeLoad();
            }
        }
    }
}